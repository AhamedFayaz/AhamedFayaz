#include <stdio.h>
extern void print_data();
int main()
{
	print_data();
	return 0;
}
