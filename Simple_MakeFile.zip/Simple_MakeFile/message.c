#include <stdio.h>
void print_data();

void print_data()
{
	printf("Hello World\n");
}
